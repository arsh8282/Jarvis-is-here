import json, os, threading

from kivy.app import App
from kivy.clock import Clock
from kivy.core.clipboard import Clipboard
from kivy.core.window import Window
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.image import Image
from kivy.uix.scrollview import ScrollView
from kivy.uix.screenmanager import FadeTransition, Screen, ScreenManager
from kivy.uix.slider import Slider
from kivy.uix.spinner import Spinner
from kivy.uix.switch import Switch
from kivy.uix.togglebutton import ToggleButton

from jarvis import smali_tools
from jarvis.ai_client import GeminiClient, GeminiError
from jarvis.code_editor import EditorBuffer, diff_markup, extract_code_block
from jarvis.conversation_store import ConversationStore
from jarvis.screen_manager import ScreenTools
from jarvis.settings_manager import DEFAULT_INSTRUCTIONS, Settings
from jarvis.ui_components import (BG, CYAN, PANEL, TEXT, Bubble, Core, ask_text, btn, confirm, lbl,
                                  message, pick_file, popup, run_async, text_input)
from jarvis.voice_manager import VoiceManager

VERSION = "0.1.0"
LANGS = ["en-IN", "en-US", "en-GB", "hi-IN"]


def scroll_col(**kw):
    sv = ScrollView(**kw)
    col = BoxLayout(orientation="vertical", size_hint_y=None, spacing=dp(8), padding=dp(8))
    col.bind(minimum_height=col.setter("height"))
    sv.add_widget(col)
    return sv, col


def read_text(path):
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        return f.read()


class JarvisApp(App):
    title = "JARVIS AI"

    def build(self):
        Window.clearcolor = BG
        Window.softinput_mode = "below_target"
        d = self.user_data_dir
        self.exports = os.path.join(d, "exports")
        os.makedirs(self.exports, exist_ok=True)
        self.cfg = Settings(d)
        self.store = ConversationStore(os.path.join(d, "jarvis.db"))
        self.client = GeminiClient(self.cfg.get("api_key"), self.cfg.get("model"))
        self.voice = VoiceManager(self.cfg)
        self.screens = ScreenTools(os.path.join(d, "tmp"))
        self.buf = EditorBuffer()
        self.conv, self.busy, self.cancel, self.image = None, False, threading.Event(), None
        self.models, self.sel_range = [], None

        root = BoxLayout(orientation="vertical")
        top = BoxLayout(size_hint_y=None, height=dp(56), padding=dp(6), spacing=dp(8))
        self.core = Core()
        top.add_widget(self.core)
        col = BoxLayout(orientation="vertical")
        col.add_widget(lbl("JARVIS AI", color=CYAN, bold=True, font_size="18sp", height=dp(26)))
        self.status = lbl("", font_size="11sp", height=dp(20))
        col.add_widget(self.status)
        top.add_widget(col)
        self.speech_btn = ToggleButton(text="Speech: ON" if self.cfg.get("speech_on") else "Speech: OFF",
                                       state="down" if self.cfg.get("speech_on") else "normal",
                                       size_hint=(None, None), size=(dp(110), dp(40)),
                                       background_normal="", background_color=PANEL, color=CYAN)
        self.speech_btn.bind(on_release=self.toggle_speech)
        top.add_widget(self.speech_btn)  # upper-right toggle
        root.add_widget(top)

        self.sm = ScreenManager(transition=FadeTransition(duration=0.15))
        self.setup, self.chat_s, self.smali_s = Screen(name="setup"), Screen(name="chat"), Screen(name="smali")
        self.editor_s, self.hist_s, self.set_s = Screen(name="editor"), Screen(name="history"), Screen(name="settings")
        for s, f in ((self.setup, self.build_setup), (self.chat_s, self.build_chat), (self.smali_s, self.build_smali),
                     (self.editor_s, self.build_editor), (self.hist_s, self.build_history), (self.set_s, self.build_settings)):
            f(s)
            self.sm.add_widget(s)
        root.add_widget(self.sm)
        nav = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(2))
        for name in ("chat", "smali", "editor", "history", "settings"):
            nav.add_widget(btn(name.capitalize(), lambda n=name: self.go(n), font_size="12sp", height=dp(48)))
        root.add_widget(nav)
        Window.bind(on_keyboard=self.on_key)
        return root

    # ---------------- navigation / lifecycle ----------------
    def go(self, name):
        if name != "setup" and not (self.cfg.get("api_key") and self.cfg.get("model")):
            name = "setup"
        self.sm.current = name
        if name == "history":
            self.refresh_history()
        if name == "settings":
            self.voice_spinner.values = self.voice.voices() or ["(unavailable)"]

    def on_key(self, win, key, *a):
        if key == 27 and self.sm.current != "chat":
            self.go("chat")
            return True
        return False

    def on_start(self):
        self.refresh_status()
        if self.cfg.get("api_key") and self.cfg.get("model"):
            self.go("chat")
            self.check_connection()
        else:
            self.sm.current = "setup"
            self.setup_msg.text = "Welcome, %s. Enter your Gemini API key to initialise JARVIS." % self.cfg.get("address_as")

    def on_pause(self):
        self.voice.cancel_listening()
        return True

    def on_stop(self):
        self.voice.shutdown()

    def flash(self, text):
        self.status.text = text
        Clock.schedule_once(lambda dt: self.refresh_status(), 4)

    def refresh_status(self, conn=None):
        if conn is not None:
            self._conn = conn
        self.status.text = "%s | %s" % (self.cfg.get("model") or "no model", getattr(self, "_conn", "not checked"))

    def check_connection(self):
        def done(res, err):
            self.refresh_status("connected" if not err else "error: " + str(err)[:40])
        run_async(self.client.validate_key, done)

    def toggle_speech(self, *a):
        on = self.speech_btn.state == "down"
        self.cfg.set("speech_on", on)
        self.speech_btn.text = "Speech: ON" if on else "Speech: OFF"
        if not on:
            self.voice.stop()

    # ---------------- setup / model selection ----------------
    def build_setup(self, s):
        box = BoxLayout(orientation="vertical", padding=dp(10), spacing=dp(8))
        box.add_widget(Image(source="assets/jarvis_logo.png", size_hint_y=None, height=dp(90)))
        self.setup_msg = lbl("")
        box.add_widget(self.setup_msg)
        self.key_in = text_input(password=True, multiline=False, size_hint_y=None, height=dp(44),
                                 hint_text="Gemini API key")
        box.add_widget(self.key_in)
        row = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(8))
        show = ToggleButton(text="Show/Hide", background_normal="", background_color=PANEL, color=CYAN)
        show.bind(on_release=lambda *_: setattr(self.key_in, "password", show.state != "down"))
        row.add_widget(show)
        row.add_widget(btn("Validate & load models", self.validate_key))
        box.add_widget(row)
        self.model_search = text_input(multiline=False, size_hint_y=None, height=dp(44), hint_text="Search models")
        self.model_search.bind(text=lambda *_: self.show_models())
        box.add_widget(self.model_search)
        sv, self.model_col = scroll_col()
        box.add_widget(sv)
        s.add_widget(box)

    def validate_key(self):
        key = self.key_in.text.strip() or self.cfg.get("api_key")
        if not key:
            self.setup_msg.text = "Please enter an API key."
            return
        self.client.api_key = key
        self.setup_msg.text = "Validating key and fetching models..."

        def done(models, err):
            if err:
                self.setup_msg.text = "Failed: %s\nTap Validate to retry." % err
                return
            self.cfg.set("api_key", key)
            self.key_in.text = ""
            self.models = models
            self.setup_msg.text = "Key valid. %d models available. Select one:" % len(models)
            self.show_models()
        run_async(self.client.list_models, done)

    def show_models(self):
        self.model_col.clear_widgets()
        q = self.model_search.text.lower()
        for m in self.models:
            if q in m["name"].lower() or q in m.get("displayName", "").lower():
                self.model_col.add_widget(btn("%s\n%s" % (m.get("displayName", ""), m["name"]),
                                              lambda mm=m: self.pick_model(mm), height=dp(56), font_size="12sp"))

    def pick_model(self, m):
        self.cfg.set("model", m["name"])
        self.client.model = m["name"]
        self.refresh_status("connected")
        info = "Methods: %s\nInput token limit: %s\nImage input is not reported by the models API; JARVIS will try and report any error." % (
            ", ".join(m.get("supportedGenerationMethods", [])), m.get("inputTokenLimit", "?"))
        message("Model selected", m["name"] + "\n" + info)
        self.go("chat")

    # ---------------- chat ----------------
    def build_chat(self, s):
        box = BoxLayout(orientation="vertical")
        self.chat_sv, self.chat_col = scroll_col()
        box.add_widget(self.chat_sv)
        self.img_lbl = lbl("", font_size="12sp", height=dp(22))
        box.add_widget(self.img_lbl)
        self.input = text_input(hint_text="Message JARVIS...", size_hint_y=None, height=dp(80))
        box.add_widget(self.input)
        r1 = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(4))
        for t, f in (("Send", self.send), ("Mic", self.mic), ("Stop", self.stop_all), ("New", self.new_chat),
                     ("Screenshot", self.pick_screenshot)):
            r1.add_widget(btn(t, f, font_size="12sp"))
        box.add_widget(r1)
        s.add_widget(box)

    def bubble(self, role, text):
        acts = None
        if role == "assistant":
            acts = [("Copy", lambda: (Clipboard.copy(text), self.flash("Copied"))),
                    ("Copy code", lambda: self.copy_code(text)),
                    ("Speak again", lambda: self.voice.speak_response(text))]
        self.chat_col.add_widget(Bubble(role, text, acts))
        Clock.schedule_once(lambda dt: setattr(self.chat_sv, "scroll_y", 0), 0.1)

    def copy_code(self, text):
        code = extract_code_block(text)
        if code:
            Clipboard.copy(code)
        self.flash("Code copied" if code else "No code block found")

    def new_chat(self):
        self.conv, self.image = None, None
        self.chat_col.clear_widgets()
        self.img_lbl.text = ""

    def open_conv(self, cid):
        self.new_chat()
        self.conv = cid
        for r, t in self.store.messages(cid):
            self.bubble(r, t)
        self.go("chat")

    def send(self):
        text = self.input.text.strip()
        if not text or self.busy:
            return
        if not self.cfg.get("model"):
            return self.go("setup")
        if self.conv is None:
            self.conv = self.store.new(text[:40])
        self.store.add(self.conv, "user", text)
        self.bubble("user", text)
        self.input.text = ""
        history, img = self.store.messages(self.conv), self.image
        self.busy, self.core.active = True, True
        self.cancel = ev = threading.Event()
        self.status.text = "JARVIS is thinking..."

        def work():
            return self.client.generate(history, self.cfg.system_prompt(), img, ev)

        def done(res, err):
            self.busy, self.core.active = False, False
            self.refresh_status()
            if ev.is_set():
                return self.flash("Cancelled")
            if err:
                if isinstance(err, GeminiError) and err.kind == "key":
                    err = "%s\nUpdate the key in Settings > Change API key (history is kept)." % err
                return self.bubble("system", str(err))
            self.store.add(self.conv, "assistant", res)
            self.bubble("assistant", res)
            if self.cfg.get("speech_on"):
                self.voice.speak_response(res)
        run_async(work, done)

    def stop_all(self):
        self.cancel.set()
        self.voice.stop()
        self.voice.cancel_listening()
        self.busy, self.core.active = False, False
        self.flash("Stopped")

    def mic(self):
        if self.voice.listening:
            return self.voice.stop_listening()
        self.voice.listen(lambda t: (setattr(self.input, "text", (self.input.text + " " + t).strip()), self.flash("Heard. Edit or send.")),
                          lambda st: setattr(self.core, "active", st == "listening"),
                          lambda e: (setattr(self.core, "active", False), self.flash(e)))
        self.flash("Listening... tap Mic again to stop")

    def pick_screenshot(self):
        if not self.cfg.get("screen_awareness"):
            return message("Screen Awareness is OFF", "Enable Screen Awareness in Settings to attach screenshots.")
        def got(path):
            try:
                self.image = self.screens.import_image(path)
                self.img_lbl.text = "Attached: " + os.path.basename(self.image) + " (sent with your next message)"
            except Exception as e:
                message("Image error", str(e))
        pick_file(got)

    # ---------------- Smali tools ----------------
    def build_smali(self, s):
        box = BoxLayout(orientation="vertical", padding=dp(6), spacing=dp(6))
        self.mode = Spinner(text="Find False Condition", values=list(smali_tools.MODES), size_hint_y=None,
                            height=dp(44), background_normal="", background_color=PANEL, color=CYAN)
        box.add_widget(self.mode)
        self.smali_code = text_input(hint_text="Paste Smali / log / XML here", size_hint_y=0.4)
        box.add_widget(self.smali_code)
        self.smali_q = text_input(hint_text="Your question (optional)", multiline=False, size_hint_y=None, height=dp(44))
        box.add_widget(self.smali_q)
        r = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(4))
        r.add_widget(btn("Open", lambda: pick_file(lambda p: setattr(self.smali_code, "text", read_text(p))), font_size="12sp"))
        r.add_widget(btn("Opcodes", lambda: self.show_out(smali_tools.explain_opcodes(self.smali_code.text)), font_size="12sp"))
        r.add_widget(btn("Local trace", lambda: self.show_out(smali_tools.analyze(self.smali_code.text)), font_size="12sp"))
        r.add_widget(btn("Ask JARVIS", self.smali_ask, font_size="12sp"))
        box.add_widget(r)
        sv, col = scroll_col(size_hint_y=0.45)
        self.smali_out = lbl("", size_hint_y=None)
        col.add_widget(self.smali_out)
        box.add_widget(sv)
        box.add_widget(btn("Copy result", lambda: Clipboard.copy(self.smali_out.text), height=dp(36)))
        s.add_widget(box)

    def show_out(self, t):
        self.smali_out.text = t

    def smali_ask(self):
        code = self.smali_code.text.strip()
        if not code or self.busy:
            return
        prompt = smali_tools.build_prompt(self.mode.text, code, self.smali_q.text.strip())
        self.busy, self.core.active = True, True
        self.smali_out.text = "Analysing..."

        def done(res, err):
            self.busy, self.core.active = False, False
            self.smali_out.text = str(err) if err else res
            if res and self.cfg.get("speech_on"):
                self.voice.speak_response(res)
        run_async(lambda: self.client.generate([("user", prompt)], self.cfg.system_prompt()), done)

    # ---------------- code editor ----------------
    def build_editor(self, s):
        box = BoxLayout(orientation="vertical", padding=dp(6), spacing=dp(6))
        self.ed_path = lbl("(unsaved buffer)", font_size="12sp", height=dp(22))
        box.add_widget(self.ed_path)
        self.ed = text_input(hint_text="Paste or open code. Select lines, then ask JARVIS.", size_hint_y=0.5)
        box.add_widget(self.ed)
        self.ed_act = Spinner(text="Explain", values=["Explain", "Debug", "Suggest change"], size_hint_y=None,
                              height=dp(40), background_normal="", background_color=PANEL, color=CYAN)
        box.add_widget(self.ed_act)
        r = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(4))
        for t, f in (("Open", self.ed_open), ("Ask", self.ed_ask), ("Undo", self.ed_undo),
                     ("Save copy", self.ed_save), ("Copy", self.ed_copy)):
            r.add_widget(btn(t, f, font_size="12sp"))
        box.add_widget(r)
        sv, col = scroll_col(size_hint_y=0.35)
        self.ed_out = lbl("", markup=True)
        col.add_widget(self.ed_out)
        box.add_widget(sv)
        self.ed_review = btn("Review suggested change", self.ed_show_diff, height=dp(40))
        self.ed_reply = None
        box.add_widget(self.ed_review)
        s.add_widget(box)

    def ed_open(self):
        def got(p):
            try:
                self.ed.text = read_text(p)
                self.buf.load(self.ed.text, p)
                self.ed_path.text = p
            except OSError as e:
                message("Open failed", str(e))
        pick_file(got)

    def ed_copy(self):
        Clipboard.copy(self.ed.selection_text or self.ed.text)
        self.flash("Copied")

    def ed_ask(self):
        if self.busy:
            return
        sel = self.ed.selection_text
        self.sel_range = (self.ed.selection_from, self.ed.selection_to) if sel else None
        if self.sel_range:
            self.sel_range = tuple(sorted(self.sel_range))
        code = sel or self.ed.text
        if not code.strip():
            return
        ask = {"Explain": "Explain this code.", "Debug": "Find problems in this code and explain them.",
               "Suggest change": "Suggest a minimal change. Put the full replacement for exactly this code in ONE code block."}[self.ed_act.text]
        self.busy, self.core.active = True, True
        self.ed_out.text = "Thinking..."
        prompt = "%s\n\n```\n%s\n```" % (ask, code)

        def done(res, err):
            self.busy, self.core.active = False, False
            self.ed_reply = res
            from jarvis.code_editor import esc
            self.ed_out.text = esc(str(err) if err else res)
        run_async(lambda: self.client.generate([("user", prompt)], self.cfg.system_prompt()), done)

    def ed_show_diff(self):
        new = extract_code_block(self.ed_reply or "")
        if new is None:
            return message("No suggestion", "The last reply has no code block to apply.")
        a, b = self.sel_range or (0, len(self.ed.text))
        old = self.ed.text[a:b]
        box = BoxLayout(orientation="vertical", spacing=dp(6))
        sv, col = scroll_col()
        col.add_widget(lbl(diff_markup(old, new), markup=True, font_name="RobotoMono-Regular", font_size="12sp"))
        box.add_widget(sv)
        row = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(8))
        p = popup("Review change (original is kept until you apply)", box)

        def apply():
            self.buf.push(self.ed.text)
            self.ed.text = self.ed.text[:a] + new + self.ed.text[b:]
            p.dismiss()
            self.flash("Applied. Use Undo to revert.")
        row.add_widget(btn("Reject", p.dismiss))
        row.add_widget(btn("Apply", apply))
        box.add_widget(row)

    def ed_undo(self):
        prev = self.buf.undo()
        if prev is None:
            return self.flash("Nothing to undo")
        self.ed.text = prev

    def ed_save(self):
        path = self.buf.save_path(self.exports)

        def write():
            with open(path, "w", encoding="utf-8") as f:
                f.write(self.ed.text)
            message("Saved", "Saved a copy (original untouched):\n" + path)
        if os.path.exists(path):
            confirm("Overwrite?", "%s already exists. Overwrite this copy?" % path, write)
        else:
            write()

    # ---------------- history ----------------
    def build_history(self, s):
        box = BoxLayout(orientation="vertical", padding=dp(6), spacing=dp(6))
        r = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(4))
        r.add_widget(btn("Import JSON", self.import_conv, font_size="12sp"))
        r.add_widget(btn("Clear all", lambda: confirm("Delete everything?", "Delete ALL conversations? This cannot be undone.",
                                                       lambda: (self.store.clear_all(), self.new_chat(), self.refresh_history())), font_size="12sp"))
        box.add_widget(r)
        sv, self.hist_col = scroll_col()
        box.add_widget(sv)
        s.add_widget(box)

    def refresh_history(self):
        self.hist_col.clear_widgets()
        for cid, title in self.store.list():
            row = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(3))
            row.add_widget(btn(title[:28], lambda c=cid: self.open_conv(c), font_size="12sp"))
            row.add_widget(btn("Name", lambda c=cid, t=title: ask_text("Rename", t, lambda v: (self.store.rename(c, v), self.refresh_history())), font_size="11sp", size_hint_x=None, width=dp(52)))
            row.add_widget(btn("JSON", lambda c=cid: self.export(c, True), font_size="11sp", size_hint_x=None, width=dp(52)))
            row.add_widget(btn("TXT", lambda c=cid: self.export(c, False), font_size="11sp", size_hint_x=None, width=dp(48)))
            row.add_widget(btn("Del", lambda c=cid: confirm("Delete", "Delete this conversation?", lambda: (self.store.delete(c), self.refresh_history())), font_size="11sp", size_hint_x=None, width=dp(44)))
            self.hist_col.add_widget(row)

    def export(self, cid, as_json):
        p = os.path.join(self.exports, "conversation_%d.%s" % (cid, "json" if as_json else "txt"))
        with open(p, "w", encoding="utf-8") as f:
            f.write(self.store.export_json(cid) if as_json else self.store.export_text(cid))
        message("Exported", p + "\n(API keys are never included.)")

    def import_conv(self):
        def got(p):
            try:
                self.store.import_json(read_text(p))
                self.refresh_history()
            except (ValueError, OSError) as e:
                message("Import failed", str(e))
        pick_file(got)

    # ---------------- settings ----------------
    def build_settings(self, s):
        sv, c = scroll_col()
        g = self.cfg.get

        def spin(label, key, values):
            c.add_widget(lbl(label, font_size="12sp"))
            sp = Spinner(text=str(g(key)), values=values, size_hint_y=None, height=dp(40),
                         background_normal="", background_color=PANEL, color=CYAN)
            sp.bind(text=lambda w, v: self.cfg.set(key, v))
            c.add_widget(sp)
            return sp
        c.add_widget(lbl("AI", color=CYAN, bold=True))
        c.add_widget(btn("Change / validate API key & refresh models", lambda: self._to_setup()))
        c.add_widget(lbl("Voice", color=CYAN, bold=True))
        spin("Speech language", "speech_lang", LANGS)
        spin("Voice-input language", "mic_lang", LANGS)
        self.voice_spinner = spin("Voice (after TTS is ready)", "voice_name", ["(open Settings again)"])
        c.add_widget(lbl("Speech rate", font_size="12sp"))
        sl = Slider(min=0.5, max=2.0, value=g("speech_rate"), size_hint_y=None, height=dp(36))
        sl.bind(value=lambda w, v: self.cfg.set("speech_rate", round(v, 2)))
        c.add_widget(sl)
        c.add_widget(btn("Stop speaking", self.voice.stop))
        c.add_widget(lbl("Screen Awareness (screenshot import only; live capture not implemented)", color=CYAN, bold=True))
        sw = Switch(active=g("screen_awareness"), size_hint_y=None, height=dp(40))
        sw.bind(active=lambda w, v: self.cfg.set("screen_awareness", v))
        c.add_widget(sw)
        c.add_widget(btn("Clear temporary images", lambda: self.flash("Removed %d images" % self.screens.clear())))
        c.add_widget(lbl("Assistant", color=CYAN, bold=True))
        for label, key, vals in (("Preferred language", "language", ["Hinglish", "English", "Hindi"]),
                                 ("Personality", "personality", ["Professional and calm", "Friendly", "Concise and direct"]),
                                 ("Response length", "response_length", ["Short", "Balanced", "Detailed"]),
                                 ("Explanation depth", "depth", ["Simple", "Detailed", "Expert"]),
                                 ("Coding style", "coding_style", ["Clean and minimal", "Heavily commented"]),
                                 ("Smali explanation style", "smali_style", ["Line-by-line in Hinglish", "Line-by-line in English", "Summary only"])):
            spin(label, key, vals)
        for label, key in (("Assistant name", "assistant_name"), ("Address me as", "address_as")):
            c.add_widget(lbl(label, font_size="12sp"))
            ti = text_input(text=g(key), multiline=False, size_hint_y=None, height=dp(40))
            ti.bind(on_text_validate=lambda w, k=key: self.cfg.set(k, w.text), focus=lambda w, f, k=key: (not f) and self.cfg.set(k, w.text))
            c.add_widget(ti)
        c.add_widget(lbl("Custom instructions", font_size="12sp"))
        self.instr = text_input(text=g("instructions"), size_hint_y=None, height=dp(180))
        c.add_widget(self.instr)
        r = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(4))
        r.add_widget(btn("Save", lambda: (self.cfg.set("instructions", self.instr.text), self.flash("Instructions saved"))))
        r.add_widget(btn("Default", lambda: setattr(self.instr, "text", DEFAULT_INSTRUCTIONS)))
        r.add_widget(btn("Clear", lambda: setattr(self.instr, "text", "")))
        c.add_widget(r)
        c.add_widget(lbl("Storage", color=CYAN, bold=True))
        c.add_widget(btn("Reset settings (keeps API key)", lambda: confirm("Reset", "Reset all settings to defaults?", self._reset)))
        c.add_widget(lbl("About", color=CYAN, bold=True))
        c.add_widget(lbl("JARVIS AI %s\nPermissions: INTERNET (Gemini), RECORD_AUDIO (voice input, asked on first use).\n"
                         "Privacy: your messages (and a screenshot only if you attach one) are sent to Google's Gemini API. "
                         "The API key is stored unencrypted in app-private storage; anyone with root or a backup can read it. "
                         "Not implemented: live screen capture, floating overlay, theme/appearance options." % VERSION, font_size="12sp"))
        s.add_widget(sv)

    def _to_setup(self):
        self.sm.current = "setup"

    def _reset(self):
        self.cfg.reset()
        self.flash("Settings reset. Reopen the app to refresh all controls.")


if __name__ == "__main__":
    JarvisApp().run()
