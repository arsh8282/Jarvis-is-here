[app]
title = JARVIS AI
package.name = jarvisai
# CUSTOMIZE: change the domain to one you own
package.domain = org.example
source.dir = .
source.include_exts = py,png,jpg,kv,atlas,json,txt
source.exclude_dirs = bin,.buildozer,.git,.github,__pycache__
version = 0.1.0
requirements = python3,kivy==2.3.0,pyjnius,android,plyer,requests,urllib3,charset-normalizer,idna,certifi,sqlite3
orientation = portrait
fullscreen = 0
icon.filename = %(source.dir)s/assets/app_icon.png
android.permissions = INTERNET,RECORD_AUDIO
android.api = 33
android.minapi = 24
android.ndk = 25b
android.archs = arm64-v8a
android.accept_sdk_license = True
android.enable_androidx = True
android.window_soft_input_mode = adjustResize

[buildozer]
log_level = 2
warn_on_root = 1
