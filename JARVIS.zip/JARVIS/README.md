# JARVIS AI (Python + Kivy + Gemini)

Android AI assistant for Smali/APK-modding help. Python/Kivy app, Gemini Developer API, built to an APK by GitHub Actions + Buildozer.

## Status (read first)
**Implemented:** Gemini key validation, dynamic model list + search, multi-turn chat with system instructions, image (screenshot) analysis, SQLite history (rename/delete/export/import), speech ON/OFF toggle (top-right) with spoken summaries, Android TTS + SpeechRecognizer voice input, Smali tools (offline conditional/register trace + 15 Gemini modes), code editor with diff review/apply/undo/save-copy, settings, custom instructions.
**NOT implemented:** live screen capture (MediaProjection), system-wide floating bubble/overlay, line-number gutter, theme/appearance settings, secure Keystore storage, APK decode/rebuild.
**Not verified:** the Android build and on-device behaviour (TTS, STT, file picker) have not been run. Only Python syntax and the pure-Python logic were tested. Expect to iterate on the first GitHub build.

## Setup
1. Get a key at https://aistudio.google.com/apikey.
2. Create a GitHub repo, upload all files (keep `.github/workflows/build.yml`), push to `main`.
3. Open **Actions → Build JARVIS AI APK** (or run it with *Run workflow*). First build takes 30–60+ min.
4. When green, open the run → **Artifacts → jarvis-ai-debug-apk**, download and unzip, copy the `.apk` to the phone, allow "install unknown apps", install.
5. Launch, paste the key, **Validate**, pick a model. Mic permission is requested on first Mic tap. Enable **Screen Awareness** in Settings to attach screenshots (picked by you; nothing is captured automatically).

Before publishing, change `package.domain` in `buildozer.spec`.

## Desktop run
`pip install -r requirements.txt && python main.py` (voice features are no-ops off Android).

## Troubleshooting
- *Build fails on a recipe*: check the uploaded `build.log`; pin/remove the failing package in `buildozer.spec`.
- *Mic does nothing on Android 11+*: some devices need a package-visibility `<queries>` entry for the speech service; also confirm a recognition service (Google app) is installed.
- *File picker returns nothing*: plyer cannot resolve some cloud/content URIs; pick from local storage.
- Saved files go to app-private `exports/` (original files are never overwritten); use the Copy button or a file manager with access to move content out.

## Security
The API key is stored unencrypted in app-private storage. Anyone with root/backup access can read it, and a client-side key can always be extracted from a device. Restrict the key in Google AI Studio, or put a backend proxy in front of `ai_client.py`. Keys are never logged, hard-coded or exported. Messages and attached images are sent to Google.
