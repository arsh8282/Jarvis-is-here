"""Thin pyjnius bridge: permissions, TextToSpeech, SpeechRecognizer. Degrades to no-ops on desktop."""
try:
    from jnius import autoclass, PythonJavaClass, java_method
    from android.permissions import request_permissions, Permission, check_permission
    from android.runnable import run_on_ui_thread
    ON_ANDROID = True
except Exception:  # desktop / tests
    ON_ANDROID = False
    PythonJavaClass = object

    def java_method(*a, **k):
        return lambda f: f

    def run_on_ui_thread(f):
        return f


def activity():
    return autoclass("org.kivy.android.PythonActivity").mActivity


def has_mic_permission():
    return (not ON_ANDROID) or check_permission(Permission.RECORD_AUDIO)


def request_mic(callback):
    if not ON_ANDROID:
        return callback(True)
    request_permissions([Permission.RECORD_AUDIO], lambda p, g: callback(bool(g and all(g))))


class _InitListener(PythonJavaClass):
    __javainterfaces__ = ["android/speech/tts/TextToSpeech$OnInitListener"]
    __javacontext__ = "app"

    def __init__(self, cb):
        super().__init__()
        self.cb = cb

    @java_method("(I)V")
    def onInit(self, status):
        self.cb(status == 0)


class AndroidTTS:
    def __init__(self, on_ready=None):
        self.ready, self.tts, self.on_ready = False, None, on_ready
        if ON_ANDROID:
            self._init()

    @run_on_ui_thread
    def _init(self):
        TTS = autoclass("android.speech.tts.TextToSpeech")
        self._l = _InitListener(self._ready)
        self.tts = TTS(activity(), self._l)

    def _ready(self, ok):
        self.ready = ok
        if self.on_ready:
            self.on_ready(ok)

    def speak(self, text):
        if not (self.ready and self.tts):
            return False
        self.tts.speak(text[:3900], 0, None, "jarvis")  # 0 = QUEUE_FLUSH: no overlapping speech
        return True

    def stop(self):
        if self.tts and self.ready:
            self.tts.stop()

    def is_speaking(self):
        return bool(self.tts and self.ready and self.tts.isSpeaking())

    def configure(self, rate, lang_tag, voice_name=""):
        if not (self.ready and self.tts):
            return
        self.tts.setSpeechRate(float(rate))
        self.tts.setLanguage(autoclass("java.util.Locale").forLanguageTag(lang_tag))
        if voice_name:
            for v in self.tts.getVoices().toArray():
                if v.getName() == voice_name:
                    self.tts.setVoice(v)

    def voices(self):
        if not (self.ready and self.tts):
            return []
        return sorted(v.getName() for v in self.tts.getVoices().toArray())

    def shutdown(self):
        if self.tts:
            self.tts.stop()
            self.tts.shutdown()
            self.tts = None


class _RecListener(PythonJavaClass):
    __javainterfaces__ = ["android/speech/RecognitionListener"]
    __javacontext__ = "app"

    def __init__(self, on_text, on_state, on_error):
        super().__init__()
        self.on_text, self.on_state, self.on_error = on_text, on_state, on_error

    @java_method("(Landroid/os/Bundle;)V")
    def onReadyForSpeech(self, b):
        self.on_state("listening")

    @java_method("()V")
    def onBeginningOfSpeech(self):
        pass

    @java_method("(F)V")
    def onRmsChanged(self, rms):
        pass

    @java_method("([B)V")
    def onBufferReceived(self, buf):
        pass

    @java_method("()V")
    def onEndOfSpeech(self):
        self.on_state("processing")

    @java_method("(I)V")
    def onError(self, code):
        self.on_error(code)

    @java_method("(Landroid/os/Bundle;)V")
    def onResults(self, b):
        r = b.getStringArrayList("results_recognition")
        self.on_text(str(r.get(0)) if r is not None and r.size() > 0 else "")

    @java_method("(Landroid/os/Bundle;)V")
    def onPartialResults(self, b):
        pass

    @java_method("(ILandroid/os/Bundle;)V")
    def onEvent(self, t, b):
        pass


ERRORS = {1: "network timeout", 2: "network error", 3: "audio error", 4: "server error", 5: "client error",
          6: "no speech heard", 7: "no match", 8: "recognizer busy", 9: "permission denied"}


class AndroidSTT:
    def __init__(self):
        self.rec, self.listener = None, None

    def available(self):
        if not ON_ANDROID:
            return False
        return bool(autoclass("android.speech.SpeechRecognizer").isRecognitionAvailable(activity()))

    @run_on_ui_thread
    def start(self, lang, on_text, on_state, on_error):
        SR = autoclass("android.speech.SpeechRecognizer")
        RI = autoclass("android.speech.RecognizerIntent")
        Intent = autoclass("android.content.Intent")
        self._destroy()
        self.listener = _RecListener(on_text, on_state, on_error)
        self.rec = SR.createSpeechRecognizer(activity())
        self.rec.setRecognitionListener(self.listener)
        i = Intent(RI.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RI.EXTRA_LANGUAGE_MODEL, RI.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RI.EXTRA_LANGUAGE, lang)
        i.putExtra(RI.EXTRA_MAX_RESULTS, 1)
        self.rec.startListening(i)

    @run_on_ui_thread
    def stop(self):
        if self.rec:
            self.rec.stopListening()

    @run_on_ui_thread
    def cancel(self):
        self._destroy()

    def _destroy(self):
        if self.rec:
            try:
                self.rec.cancel()
                self.rec.destroy()
            finally:
                self.rec = None
