"""Persistent JSON settings. NOTE: the API key is stored in the app-private
directory (not encrypted). See README 'API key security'."""
import json, os

DEFAULT_INSTRUCTIONS = (
    "You are JARVIS, my personal AI assistant. Address me as Sir. Explain technical topics in simple "
    "Hinglish unless I request another language. Focus on Android development, APK modding, Smali "
    "debugging, and accurate step-by-step explanations. Analyze the actual code before identifying "
    "errors. Explain important Smali instructions in understandable language. Identify the exact "
    "relevant lines, explain why they behave as they do, and provide a minimal correction when "
    "supported by the evidence.")

DEFAULTS = {
    "api_key": "", "model": "", "speech_on": False, "voice_name": "", "speech_rate": 1.0,
    "speech_lang": "en-IN", "mic_lang": "en-IN", "screen_awareness": False,
    "assistant_name": "JARVIS", "address_as": "Sir", "language": "Hinglish",
    "personality": "Professional and calm", "response_length": "Balanced", "depth": "Detailed",
    "coding_style": "Clean and minimal", "smali_style": "Line-by-line in Hinglish",
    "examples": True, "instructions": DEFAULT_INSTRUCTIONS,
}


class Settings:
    def __init__(self, directory):
        os.makedirs(directory, exist_ok=True)
        self.path = os.path.join(directory, "settings.json")
        self.data = dict(DEFAULTS)
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                saved = json.load(f)
            self.data.update({k: v for k, v in saved.items() if k in DEFAULTS})
        except (OSError, ValueError):
            pass

    def get(self, key):
        return self.data.get(key, DEFAULTS.get(key))

    def set(self, key, value):
        self.data[key] = value
        self.save()

    def save(self):
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(self.data, f)
        try:
            os.chmod(tmp, 0o600)
        except OSError:
            pass
        os.replace(tmp, self.path)

    def reset(self, keep_key=True):
        key, model = self.data["api_key"], self.data["model"]
        self.data = dict(DEFAULTS)
        if keep_key:
            self.data["api_key"], self.data["model"] = key, model
        self.save()

    def system_prompt(self):
        g = self.get
        parts = [g("instructions").strip(),
                 f"Your name is {g('assistant_name')}. Address the user as {g('address_as')}.",
                 f"Preferred language: {g('language')}. Personality: {g('personality')}.",
                 f"Response length: {g('response_length')}. Explanation depth: {g('depth')}.",
                 f"Coding style: {g('coding_style')}. Smali explanation style: {g('smali_style')}.",
                 "Include short examples where helpful." if g("examples") else "Avoid examples unless asked.",
                 "Never claim to have run code, builds or tests you did not run. State uncertainty and "
                 "missing context explicitly."]
        return "\n".join(p for p in parts if p)
