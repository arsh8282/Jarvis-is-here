"""Gemini Developer API client (REST, v1beta). Blocking calls: run off the UI thread."""
import base64, mimetypes, os
import requests

BASE = "https://generativelanguage.googleapis.com/v1beta"
MAX_IMAGE_BYTES = 15 * 1024 * 1024


class GeminiError(Exception):
    def __init__(self, msg, kind="error"):
        super().__init__(msg)
        self.kind = kind  # key | quota | network | model | cancelled | error


class GeminiClient:
    def __init__(self, api_key="", model="", timeout=60):
        self.api_key, self.model, self.timeout = api_key, model, timeout

    def _request(self, method, url, **kw):
        if not self.api_key:
            raise GeminiError("No Gemini API key configured.", "key")
        headers = {"x-goog-api-key": self.api_key, "Content-Type": "application/json"}
        try:
            r = requests.request(method, url, headers=headers, timeout=self.timeout, **kw)
        except requests.exceptions.Timeout:
            raise GeminiError("The request timed out. Check your connection and retry.", "network")
        except requests.exceptions.RequestException:
            raise GeminiError("Network unavailable. Check your internet connection.", "network")
        if r.status_code == 200:
            return r.json()
        try:
            msg = r.json().get("error", {}).get("message", "")
        except ValueError:
            msg = ""
        msg = (msg or r.text[:200]).replace(self.api_key, "***")
        s = r.status_code
        if s in (400, 401, 403) and ("API key" in msg or s in (401, 403)):
            raise GeminiError("API key rejected: " + msg, "key")
        if s == 404:
            raise GeminiError("Model not available: " + msg, "model")
        if s == 429:
            raise GeminiError("Rate limit or quota reached. Wait and retry. " + msg, "quota")
        if s >= 500:
            raise GeminiError("Gemini service error (%d). Retry shortly." % s, "network")
        raise GeminiError("API error %d: %s" % (s, msg), "error")

    def list_models(self):
        """Models that support generateContent, exactly as returned by the API."""
        out, token = [], None
        while True:
            params = {"pageSize": 1000}
            if token:
                params["pageToken"] = token
            data = self._request("GET", BASE + "/models", params=params)
            for m in data.get("models", []):
                if "generateContent" in m.get("supportedGenerationMethods", []):
                    out.append(m)
            token = data.get("nextPageToken")
            if not token:
                return out

    def validate_key(self):
        return self.list_models()

    def generate(self, messages, system="", image_path=None, cancel=None):
        """messages: list of (role, text) with role 'user'|'assistant'."""
        if not self.model:
            raise GeminiError("No model selected.", "model")
        contents = [{"role": "user" if r == "user" else "model", "parts": [{"text": t}]}
                    for r, t in messages]
        if image_path:
            size = os.path.getsize(image_path)
            if size > MAX_IMAGE_BYTES:
                raise GeminiError("Image is larger than 15 MB.", "error")
            mime = mimetypes.guess_type(image_path)[0] or "image/png"
            with open(image_path, "rb") as f:
                b64 = base64.b64encode(f.read()).decode()
            contents[-1]["parts"].append({"inlineData": {"mimeType": mime, "data": b64}})
        body = {"contents": contents}
        if system:
            body["systemInstruction"] = {"parts": [{"text": system}]}
        data = self._request("POST", "%s/%s:generateContent" % (BASE, self.model), json=body)
        if cancel is not None and cancel.is_set():
            raise GeminiError("Cancelled.", "cancelled")
        return self.parse(data)

    @staticmethod
    def parse(data):
        cands = data.get("candidates") or []
        if not cands:
            reason = data.get("promptFeedback", {}).get("blockReason", "unknown")
            raise GeminiError("No response (blocked: %s)." % reason, "error")
        parts = cands[0].get("content", {}).get("parts", [])
        text = "".join(p.get("text", "") for p in parts).strip()
        if not text:
            raise GeminiError("Empty response (finish reason: %s)." % cands[0].get("finishReason"), "error")
        return text
