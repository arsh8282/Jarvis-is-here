import re
from kivy.clock import Clock
from . import android_bridge as ab


def spoken_summary(text, address="Sir", limit=450):
    t = re.sub(r"```.*?```", " ", text, flags=re.S)
    t = re.sub(r"`[^`]*`|https?://\S+|[*#]", " ", t)
    t = re.sub(r"\s+", " ", t).strip()
    if not t:
        return "%s, the response contains code. Please read it on screen." % address
    out = ""
    for s in re.split(r"(?<=[.!?\u0964])\s+", t):
        if len(out) + len(s) > limit:
            break
        out += s + " "
    return (out or t[:limit]).strip()


class VoiceManager:
    def __init__(self, settings):
        self.s, self.tts, self.stt = settings, ab.AndroidTTS(), ab.AndroidSTT()
        self.listening, self.last_spoken = False, ""

    def _cfg(self):
        self.tts.configure(self.s.get("speech_rate"), self.s.get("speech_lang"), self.s.get("voice_name"))

    def speak_response(self, text):
        return self.speak(spoken_summary(text, self.s.get("address_as")))

    def speak(self, text):
        self._cfg()
        self.last_spoken = text
        return self.tts.speak(text)

    def stop(self):
        self.tts.stop()

    def speaking(self):
        return self.tts.is_speaking()

    def voices(self):
        return self.tts.voices()

    def listen(self, on_text, on_state, on_error):
        if self.listening:
            return
        if not self.stt.available():
            return on_error("Speech recognition is not available on this device/build.")

        def go(granted):
            if not granted:
                return Clock.schedule_once(lambda dt: on_error("Microphone permission denied."))
            self.listening = True
            self.tts.stop()

            def done(text):
                self.listening = False
                Clock.schedule_once(lambda dt: on_text(text) if text else on_error("Nothing recognised."))

            def err(code):
                self.listening = False
                Clock.schedule_once(lambda dt: on_error("Voice input: " + ab.ERRORS.get(code, str(code))))
            self.stt.start(self.s.get("mic_lang"), done,
                           lambda st: Clock.schedule_once(lambda dt: on_state(st)), err)
        if ab.has_mic_permission():
            go(True)
        else:
            ab.request_mic(go)

    def stop_listening(self):
        self.stt.stop()

    def cancel_listening(self):
        self.listening = False
        self.stt.cancel()

    def shutdown(self):
        self.cancel_listening()
        self.tts.shutdown()
