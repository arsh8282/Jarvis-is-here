import difflib, os, re


def esc(s):
    return s.replace("&", "&amp;").replace("[", "&bl;").replace("]", "&br;")


def extract_code_block(reply):
    m = re.search(r"```[\w+-]*\n(.*?)```", reply, re.S)
    return m.group(1).rstrip("\n") if m else None


def diff_markup(old, new):
    """Kivy markup: red=removed, green=added, yellow=modified."""
    a, b = old.splitlines(), new.splitlines()
    out = []
    for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(None, a, b).get_opcodes():
        if tag == "equal":
            out += ["  " + esc(x) for x in a[i1:i2]]
        elif tag == "delete":
            out += ["[color=ff5555]- %s[/color]" % esc(x) for x in a[i1:i2]]
        elif tag == "insert":
            out += ["[color=55ff7f]+ %s[/color]" % esc(x) for x in b[j1:j2]]
        else:
            out += ["[color=ff5555]- %s[/color]" % esc(x) for x in a[i1:i2]]
            out += ["[color=ffd24d]~ %s[/color]" % esc(x) for x in b[j1:j2]]
    return "\n".join(out)


class EditorBuffer:
    """Keeps the original until a change is approved; supports undo."""
    def __init__(self):
        self.original, self.path, self.undo_stack = "", None, []

    def load(self, text, path=None):
        self.original, self.path, self.undo_stack = text, path, []

    def push(self, current):
        self.undo_stack.append(current)

    def undo(self):
        return self.undo_stack.pop() if self.undo_stack else None

    def save_path(self, export_dir):
        name = os.path.basename(self.path) if self.path else "untitled.txt"
        base, ext = os.path.splitext(name)
        return os.path.join(export_dir, base + ".modified" + ext)
