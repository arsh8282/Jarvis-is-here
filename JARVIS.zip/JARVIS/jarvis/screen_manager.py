import mimetypes, os, shutil, time


class ScreenTools:
    """Screenshot import is implemented. Live MediaProjection capture and the system overlay are NOT."""
    LIVE_CAPTURE_IMPLEMENTED = False
    OVERLAY_IMPLEMENTED = False

    def __init__(self, tmp_dir):
        self.tmp = tmp_dir
        os.makedirs(tmp_dir, exist_ok=True)

    def import_image(self, path):
        mime = mimetypes.guess_type(path)[0] or ""
        if not mime.startswith("image/"):
            raise ValueError("Please choose an image file (png/jpg/webp).")
        dst = os.path.join(self.tmp, "shot_%d%s" % (time.time(), os.path.splitext(path)[1].lower()))
        shutil.copyfile(path, dst)
        return dst

    def clear(self):
        n = 0
        for f in os.listdir(self.tmp):
            try:
                os.remove(os.path.join(self.tmp, f))
                n += 1
            except OSError:
                pass
        return n

    def status(self):
        return "Live capture: not implemented | Screenshot import: ready"
