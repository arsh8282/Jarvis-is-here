import threading
from kivy.clock import Clock
from kivy.graphics import Color, Ellipse, Line, RoundedRectangle
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.filechooser import FileChooserListView
from kivy.uix.label import Label
from kivy.uix.popup import Popup
from kivy.uix.textinput import TextInput
from kivy.uix.widget import Widget
from math import sin

BG = (0.04, 0.07, 0.12, 1)
PANEL = (0.09, 0.14, 0.23, 1)
CYAN = (0.0, 0.82, 1.0, 1)
USER_BG = (0.04, 0.28, 0.46, 1)
AI_BG = (0.1, 0.15, 0.24, 1)
ERR_BG = (0.4, 0.1, 0.12, 1)
TEXT = (0.9, 0.96, 1, 1)


def run_async(fn, cb):
    """Run fn in a thread; cb(result, error) is invoked on the Kivy main thread."""
    def work():
        try:
            res, err = fn(), None
        except Exception as e:  # noqa
            res, err = None, e
        Clock.schedule_once(lambda dt: cb(res, err))
    threading.Thread(target=work, daemon=True).start()


def btn(text, cb, **kw):
    kw.setdefault("size_hint_y", None)
    kw.setdefault("height", dp(44))
    b = Button(text=text, background_normal="", background_color=PANEL, color=CYAN, **kw)
    b.bind(on_release=lambda *_: cb())
    return b


def lbl(text, **kw):
    kw.setdefault("color", TEXT)
    kw.setdefault("size_hint_y", None)
    l = Label(text=text, halign="left", valign="middle", **kw)
    l.bind(width=lambda w, v: setattr(w, "text_size", (v, None)),
           texture_size=lambda w, s: setattr(w, "height", max(dp(30), s[1] + dp(6))))
    return l


def text_input(**kw):
    return TextInput(background_color=PANEL, foreground_color=TEXT, cursor_color=CYAN, **kw)


def popup(title, content, size=(0.92, 0.8)):
    p = Popup(title=title, content=content, size_hint=size, auto_dismiss=False)
    p.open()
    return p


def message(title, text):
    box = BoxLayout(orientation="vertical", padding=dp(8), spacing=dp(8))
    box.add_widget(lbl(text, size_hint_y=1))
    p = popup(title, box, (0.9, 0.5))
    box.add_widget(btn("OK", p.dismiss))


def confirm(title, text, on_yes):
    box = BoxLayout(orientation="vertical", padding=dp(8), spacing=dp(8))
    box.add_widget(lbl(text, size_hint_y=1))
    row = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(8))
    p = popup(title, box, (0.9, 0.5))
    row.add_widget(btn("Cancel", p.dismiss))
    row.add_widget(btn("Yes", lambda: (p.dismiss(), on_yes())))
    box.add_widget(row)


def ask_text(title, initial, on_ok):
    box = BoxLayout(orientation="vertical", padding=dp(8), spacing=dp(8))
    ti = text_input(text=initial, multiline=False, size_hint_y=None, height=dp(44))
    box.add_widget(ti)
    row = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(8))
    p = popup(title, box, (0.9, 0.35))
    row.add_widget(btn("Cancel", p.dismiss))
    row.add_widget(btn("OK", lambda: (p.dismiss(), on_ok(ti.text))))
    box.add_widget(row)


def pick_file(cb):
    """cb(path). Android: system picker via plyer; elsewhere: Kivy chooser."""
    from . import android_bridge as ab
    if ab.ON_ANDROID:
        try:
            from plyer import filechooser
            filechooser.open_file(on_selection=lambda sel: Clock.schedule_once(
                lambda dt: sel and cb(sel[0])))
            return
        except Exception:
            pass
    box = BoxLayout(orientation="vertical", spacing=dp(6))
    fc = FileChooserListView(path="/")
    box.add_widget(fc)
    row = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(8))
    p = popup("Choose a file", box)
    row.add_widget(btn("Cancel", p.dismiss))
    row.add_widget(btn("Open", lambda: (p.dismiss(), fc.selection and cb(fc.selection[0]))))
    box.add_widget(row)


class Bubble(BoxLayout):
    """Chat bubble. Text is plain (markup off) so untrusted model output cannot inject markup."""
    def __init__(self, role, text, actions=None, **kw):
        super().__init__(orientation="vertical", size_hint_y=None, padding=dp(10), spacing=dp(6), **kw)
        bg = {"user": USER_BG, "assistant": AI_BG}.get(role, ERR_BG)
        with self.canvas.before:
            Color(*bg)
            self._r = RoundedRectangle(pos=self.pos, size=self.size, radius=[dp(14)])
        self.bind(pos=self._sync, size=self._sync)
        self.text = text
        self.l = Label(text=text, size_hint_y=None, halign="left", valign="top", color=TEXT, markup=False)
        self.l.bind(width=lambda w, v: setattr(w, "text_size", (v, None)), texture_size=self._fit)
        self.add_widget(self.l)
        self._extra = 0
        if actions:
            row = BoxLayout(size_hint_y=None, height=dp(34), spacing=dp(6))
            for name, fn in actions:
                row.add_widget(btn(name, fn, height=dp(34), font_size="12sp"))
            self.add_widget(row)
            self._extra = dp(40)
        self.height = dp(60)

    def _sync(self, *a):
        self._r.pos, self._r.size = self.pos, self.size

    def _fit(self, *a):
        self.l.height = self.l.texture_size[1]
        self.height = self.l.height + self._extra + dp(24)


class Core(Widget):
    """Animated JARVIS core: glowing disc + rotating rings (faster while busy/speaking)."""
    def __init__(self, **kw):
        super().__init__(size_hint=(None, None), size=(dp(44), dp(44)), **kw)
        self.t, self.active = 0.0, False
        self.bind(pos=self.draw, size=self.draw)
        Clock.schedule_interval(self.tick, 1 / 24)

    def tick(self, dt):
        self.t += dt * (4 if self.active else 1)
        self.draw()

    def draw(self, *a):
        cx, cy, r = self.center_x, self.center_y, self.width / 2
        self.canvas.clear()
        with self.canvas:
            Color(0, 0.82, 1, 0.25 + 0.15 * sin(self.t * 2))
            Ellipse(pos=(cx - r * .45, cy - r * .45), size=(r * .9, r * .9))
            Color(*CYAN)
            Line(circle=(cx, cy, r * .95, self.t * 90, self.t * 90 + 250), width=dp(1.4))
            Line(circle=(cx, cy, r * .7, -self.t * 140, -self.t * 140 + 200), width=dp(1.1))
