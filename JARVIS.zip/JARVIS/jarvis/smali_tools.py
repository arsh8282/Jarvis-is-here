"""Local (offline) Smali analysis + prompt templates for the Gemini-powered tools."""
import re

OPS = {
    "const-string": ("Loads a String literal into a register.", "Register me ek text (string) daalta hai."),
    "const": ("Loads a constant number into a register (0 also means false/null).", "Register me fixed number daalta hai (0 = false/null)."),
    "move-result": ("Stores the result of the previous invoke/filled-new-array.", "Pichhle invoke ka return value register me rakhta hai."),
    "move": ("Copies one register into another.", "Ek register ki value dusre me copy karta hai."),
    "if-eqz": ("Jumps to the label if register == 0/null/false.", "Register 0/null/false ho to label par jump."),
    "if-nez": ("Jumps to the label if register != 0 (true/non-null).", "Register 0 na ho (true/non-null) to jump."),
    "if-eq": ("Jumps if two registers are equal.", "Dono registers barabar hon to jump."),
    "if-ne": ("Jumps if two registers are not equal.", "Dono registers alag hon to jump."),
    "if-lt": ("Jumps if first < second.", "Pehla chhota ho to jump."),
    "if-ge": ("Jumps if first >= second.", "Pehla bada ya barabar ho to jump."),
    "if-gt": ("Jumps if first > second.", "Pehla bada ho to jump."),
    "if-le": ("Jumps if first <= second.", "Pehla chhota ya barabar ho to jump."),
    "goto": ("Unconditional jump to a label.", "Seedha label par jump."),
    "invoke-virtual": ("Calls an instance method (virtual dispatch).", "Object ka method call karta hai."),
    "invoke-static": ("Calls a static method.", "Static method call karta hai (object nahi chahiye)."),
    "invoke-direct": ("Calls a constructor or private method.", "Constructor/private method call karta hai."),
    "invoke-interface": ("Calls an interface method.", "Interface ka method call karta hai."),
    "new-instance": ("Allocates a new object (constructor still needs invoke-direct <init>).", "Naya object banata hai; <init> alag se call hota hai."),
    "iget": ("Reads an instance field into a register.", "Object ki field ki value padhta hai."),
    "iput": ("Writes a register into an instance field.", "Object ki field me value likhta hai."),
    "sget": ("Reads a static field.", "Static field padhta hai."),
    "sput": ("Writes a static field.", "Static field me likhta hai."),
    "return-void": ("Returns from a void method.", "Void method se wapas."),
    "return": ("Returns the register's value.", "Register ki value return karta hai."),
    "check-cast": ("Casts; throws ClassCastException if incompatible.", "Type cast; galat type par crash."),
    "instance-of": ("Stores 1 if the object is of the type, else 0.", "Type match ho to 1, warna 0."),
}
IF_NOTE = {
    "if-eqz": "jumps when v == 0 (false/null); falls through when v != 0",
    "if-nez": "jumps when v != 0 (true/non-null); falls through when v == 0",
}
_ASSIGN = r"^\s*((?:const|move|iget|sget|new-instance|instance-of|new-array|array-length|add|sub|mul)[\w/-]*)\s+%s\s*(?:,|$)"
_IF = re.compile(r"^\s*(if-[a-z]+)\s+([vp]\d+)(?:\s*,\s*([vp]\d+))?\s*,\s*(:\w+)")


def op_info(op):
    for k in sorted(OPS, key=len, reverse=True):
        if op.startswith(k):
            return OPS[k]
    return None


def explain_opcodes(code):
    seen, out = set(), []
    for ln in code.splitlines():
        m = re.match(r"^\s*([a-z][\w/-]*)\b", ln)
        if m and m.group(1) not in seen and not ln.strip().startswith("."):
            info = op_info(m.group(1))
            if info:
                seen.add(m.group(1))
                out.append("%s\n  EN: %s\n  Hinglish: %s" % (m.group(1), info[0], info[1]))
    return "\n".join(out) or "No known opcodes found."


def analyze(code):
    """Trace each conditional to the instruction that last assigned its register."""
    lines = code.splitlines()
    methods, start, name = [], 0, None
    for i, ln in enumerate(lines):
        if ln.strip().startswith(".method"):
            start, name = i, ln.strip()
        elif ln.strip().startswith(".end method") and name:
            methods.append((start, i, name))
            name = None
    if not methods:
        methods = [(0, len(lines) - 1, "(no .method found - using whole text)")]
    out = []
    for i, ln in enumerate(lines):
        m = _IF.match(ln)
        if not m:
            continue
        op, r1, r2, label = m.groups()
        ms = next((x for x in methods if x[0] <= i <= x[1]), methods[0])
        out.append("Line %d: %s\n  Method: %s" % (i + 1, ln.strip(), ms[2]))
        info = op_info(op)
        out.append("  Meaning: " + (IF_NOTE.get(op) or (info[0] if info else op)))
        tgt = next((j for j, l in enumerate(lines) if l.strip() == label), None)
        out.append("  Target %s: %s" % (label, "line %d" % (tgt + 1) if tgt is not None else "NOT found in supplied code"))
        for reg in [r for r in (r1, r2) if r]:
            found = None
            for j in range(i - 1, ms[0], -1):
                if re.match(_ASSIGN % reg, lines[j]):
                    found = j
                    break
            if found is None:
                why = "parameter register (p0 = this in instance methods)" if reg.startswith("p") else "no assignment in this method before the branch"
                out.append("  %s: %s - runtime value unknown from this code" % (reg, why))
            else:
                out.append("  %s last set at line %d: %s" % (reg, found + 1, lines[found].strip()))
                if lines[found].strip().startswith("move-result") and found > 0:
                    prev = next((lines[k].strip() for k in range(found - 1, ms[0], -1) if lines[k].strip()), "")
                    out.append("    result of call: %s" % prev)
        out.append("")
    return "\n".join(out) or "No conditional (if-*) instructions found."


FORMAT = ("Answer with these headings: Problem; Relevant line; Simple meaning (English + Hinglish); "
          "Control-flow analysis; Likely cause (only if the evidence supports it); Suggested fix (minimal "
          "snippet, original and corrected, each in its own code block); Line-by-line explanation in easy "
          "Hinglish; Verification; Confidence and missing context. Do not guess runtime values.")
MODES = {
    "Explain Smali": "Explain this Smali line by line in simple English and Hinglish, including registers, descriptors and control flow.",
    "Find False Condition": "The user asks why this check is false. Trace the conditional and the instructions assigning its register. " + FORMAT,
    "Debug a Method": "Debug this method. " + FORMAT,
    "Analyze Registers": "Analyze register usage (v/p registers, .locals/.registers, reuse, types).",
    "Explain Method Parameters": "Explain the method signature, parameter types, return type, and p-register mapping.",
    "Analyze Stack Trace": "Analyze this stack trace: root cause, relevant frames, and what to inspect next.",
    "Analyze Logcat": "Analyze this logcat output: key errors, likely causes, what is missing.",
    "Diagnose Smali Syntax Errors": "Find Smali syntax errors (labels, directives, registers, descriptors) and show minimal fixes.",
    "Explain APK Rebuild Failure": "Explain this apktool/rebuild failure and likely fixes. Do not claim a rebuild succeeded.",
    "Explain AndroidManifest Problem": "Explain this AndroidManifest.xml problem and a minimal fix.",
    "Explain DEX Error": "Explain this DEX error (method limit, invalid index, register count, etc.).",
    "Compare Original and Modified": "Compare the ORIGINAL and MODIFIED code (separated by '=====MODIFIED====='); explain behavior changes.",
    "Smali to Java Pseudocode": "Convert to Java-style pseudocode and say what is approximate.",
    "Java to Smali Mapping": "Explain how this Java maps to Smali instructions.",
    "Suggest Minimal Patch": "Suggest the smallest patch for the stated goal. Show original/corrected snippets. " + FORMAT,
}


def build_prompt(mode, code, question=""):
    local = analyze(code) if mode in ("Find False Condition", "Debug a Method", "Suggest Minimal Patch") else ""
    p = "%s\n\nUser request: %s\n\n```\n%s\n```" % (MODES[mode], question or "(none)", code)
    if local:
        p += "\n\nLocal static trace (heuristic, may be incomplete):\n" + local
    return p
