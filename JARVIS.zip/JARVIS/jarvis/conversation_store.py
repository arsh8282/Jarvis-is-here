import json, re, sqlite3, threading, time

_KEY_RE = re.compile(r"AIza[0-9A-Za-z_\-]{30,}")


class ConversationStore:
    def __init__(self, path):
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.lock = threading.Lock()
        with self.lock, self.db:
            self.db.executescript("""
            CREATE TABLE IF NOT EXISTS conversations(id INTEGER PRIMARY KEY, title TEXT, created REAL);
            CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY, conv INTEGER, role TEXT, text TEXT, ts REAL);""")

    def _q(self, sql, args=(), fetch=False):
        with self.lock, self.db:
            cur = self.db.execute(sql, args)
            return cur.fetchall() if fetch else cur.lastrowid

    def new(self, title="New conversation"):
        return self._q("INSERT INTO conversations(title,created) VALUES(?,?)", (title, time.time()))

    def add(self, conv, role, text):
        self._q("INSERT INTO messages(conv,role,text,ts) VALUES(?,?,?,?)", (conv, role, text, time.time()))

    def messages(self, conv):
        return self._q("SELECT role,text FROM messages WHERE conv=? ORDER BY id", (conv,), True)

    def list(self):
        return self._q("SELECT id,title FROM conversations ORDER BY id DESC", (), True)

    def rename(self, conv, title):
        self._q("UPDATE conversations SET title=? WHERE id=?", (title.strip() or "Untitled", conv))

    def delete(self, conv):
        self._q("DELETE FROM messages WHERE conv=?", (conv,))
        self._q("DELETE FROM conversations WHERE id=?", (conv,))

    def clear_all(self):
        self._q("DELETE FROM messages")
        self._q("DELETE FROM conversations")

    def export_json(self, conv):
        title = self._q("SELECT title FROM conversations WHERE id=?", (conv,), True)[0][0]
        msgs = [{"role": r, "text": _KEY_RE.sub("[REDACTED]", t)} for r, t in self.messages(conv)]
        return json.dumps({"format": "jarvis-conversation-v1", "title": title, "messages": msgs},
                          ensure_ascii=False, indent=2)

    def export_text(self, conv):
        return "\n\n".join("%s: %s" % (r.upper(), _KEY_RE.sub("[REDACTED]", t)) for r, t in self.messages(conv))

    def import_json(self, raw):
        data = json.loads(raw)
        if data.get("format") != "jarvis-conversation-v1" or not isinstance(data.get("messages"), list):
            raise ValueError("Unsupported conversation file.")
        conv = self.new(str(data.get("title", "Imported"))[:80])
        for m in data["messages"][:5000]:
            if isinstance(m, dict) and m.get("role") in ("user", "assistant") and isinstance(m.get("text"), str):
                self.add(conv, m["role"], m["text"][:100000])
        return conv
